<?php

namespace App\Services;


class IpsService
{
   
   static public function insertPersonActiviy(){
    
   }
}
